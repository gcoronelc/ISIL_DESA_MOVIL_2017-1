package pe.epdy.simplefactoryexample.service;

import pe.epdy.simplefactoryexample.model.CambioModel;

public interface CambioService {
    
    public CambioModel getCambio(float soles);
    
}












