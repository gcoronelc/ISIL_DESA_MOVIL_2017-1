package pe.epdy.methodfactoryexample;

import pe.epdy.methodfactoryexample.view.Principal;

public class MethodFactoryExample {

    public static void main(String[] args) {
        Principal.main(args);
    }
    
}
