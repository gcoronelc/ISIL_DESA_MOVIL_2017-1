package pe.epdy.abstractfactoryexample.factory;

public interface ServicioInformatico {
    
    public String asignarTrabajo();
    public String indicarFechaEntrega();
    public String informarSobrePago();
}
