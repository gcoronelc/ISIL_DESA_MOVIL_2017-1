package pe.epdy.abstractfactoryexample.factory;

public interface ServicioFactory {
    public ServicioInformatico crearServicio();
}
