package pe.epdy.simplefactoryexample;

import pe.epdy.simplefactoryexample.view.Principal;

public class SimpleFactoryExample {
    
    public static void main(String[] args) {
        Principal.main(args);
    }
}
