package pe.epdy.methodfactoryexample.model;

public abstract class NombresNumeros {
    
    public abstract String[] getNumeros();
    
    public abstract String getNombreNumeros(int p);
}
