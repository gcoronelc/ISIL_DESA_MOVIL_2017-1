package pe.epdy.abstractfactoryexample;

import pe.epdy.abstractfactoryexample.view.Principal;

public class AbstractFactoryExample {

    public static void main(String[] args) {
        Principal.main(args);
    }
    
}
