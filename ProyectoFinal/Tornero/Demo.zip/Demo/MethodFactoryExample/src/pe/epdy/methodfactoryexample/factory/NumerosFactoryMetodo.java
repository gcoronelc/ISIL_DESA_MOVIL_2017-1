package pe.epdy.methodfactoryexample.factory;

import pe.epdy.methodfactoryexample.model.NombresNumeros;

public interface NumerosFactoryMetodo {
    
    public NombresNumeros create();
    
}
